
from PID import PID
from car import Car
import numpy as np

def F_d_ss(v, beta):
    Tp = 1/300
    Ts = 1/60
    m = 1300 #kg
    Froll = 100 #𝑁
    a = 0.2 #𝑁𝑠^2/𝑚2
    b = 20 #𝑁𝑠/𝑚
    g = 9.8 #𝑚/𝑠^2
    fd_min = -7000 #𝑁
    zeta = 0.95
    eta_g = 0.8
    eta_d = 3.8
    rw = 0.34 #𝑚
    F_bar =  200 #𝑚𝑔/𝑠
    Te_max = 200 #Nm
    F_max = (Te_max * eta_g * eta_d) / rw * zeta #mg/s from engine
    F_min = -7000 #mg/s from brakes
    L = 2.7 #m
    delta_max = 0.05 #rad
    return m*g*np.sin(beta) + Froll + a*v**2 + b*v

class Controller:

    # Ts: sample time of the controller;
    # initial_conditions: two element vector representing the equilibrium 
    # i.e., [equilibrium of driving force Fd, equilibrium of vehicle speed]
    def __init__(self, Ts, initial_conditions):
        # parameters go here
        self.Ts = Ts
        self.Fd_cmd = initial_conditions[0]
        self.speed = initial_conditions[1]

        self.F_d_min = 1698.82 # in N, Calculated in report
        self.F_d_max = Car.F_max_force
        
        

        
        

        # states/controller initialization go here
        self.pos = 0

        self.v_controller = PID(
            4323.888, #Kp
            3647.3125, #Ki 
            0, # Kd
            1, # D term Filter
            Ts, # Sample time 
            self.Fd_cmd, 

            # Max/min commands
            self.F_d_max, self.F_d_min, 1)


    # speed, y, phi: ego vehicle's speed, lateral position, heading
    # desired_speed: user defined speed setpoint (flexible by plus minus 3 degrees up to speed limits)
    # des_lane: desired lane specified by the user. -1 is left lane, +1 is right lane
    # other_cars: each row of this list corresponds to one of the other vehicles on the road
    #             the columns are: [relative longitudinal position, relative lateral position, relative speed]
    # grade is a road grade object. Use grade.grade_at to find the road grade at any x
    def update(self, speed, x, y, phi, desired_speed, des_lane, other_cars, grade):
        Ts = self.Ts

        self.desired_y = 0
        self.vdes = 27.8 # keep speed

        self.delta_cmd = 0
        self.Fd_cmd = F_d_ss(self.vdes, grade.grade_at(x)) + self.v_controller.update(self.vdes-27.8,speed)

        
        return self.Fd_cmd, self.delta_cmd
